
# README

This folder contains various sample test files encoded with CCSDS-123.0-B-2,
as well as the original images and configuration files. The contents of each
file is described below.

- sample-XXXXXX-DDDDD-ZZZxYYYxXXX.raw

A raw image file of ZZZ bands, YYY rows, and XXX columns. The file is in BSQ
order. Samples are encoded as either signed 32-bit big-endian integers
(DDDDD=s32be) or unsigned big-endian 32-bit integers (DDDDD=u32be).

- sample-XXXXXX.flex

A file compressed according to CCSDS-123.0-B-2 for the previous image.

- sample-XXXXXX-hdr.bin

The header part of the previous CCSDS-123.0-B-2 file.

- sample-XXXXXX-hdr.txt

A text representation of the previous file.

- sample-XXXXXX-optional_tables.bin

A bitstream containing all optional tables not included in the CCSDS-123.0-B-2
file header (e.g., Weight Initialization Table). Optional tables are
concatenated, in the same order as they would be in the CCSDS-123.0-B-2 file.
Each optional table is zero-padded as necessary to reach the next byte
boundary. 

- sample-XXXXXX-error_limits.bin

A bitstream containing all error limits signaled in body part of the
CCSDS-123.0-B-2 file. Values are encoded as 16-bit big-endian unsigned
integers, and are in the same order as if they where in the CCSDS-123.0-B-2
file.

- sample-XXXXXX-hybrid_initial_accumulators.bin

A bitstream containing the initial high-resolution accumulator values,
arranged in order of increasing band index, as integers of D + gamma_0 bits.
File is zero-padded as necessary to reach the next byte boundary.

- sample-XXXXXX-sit_YY.txt

A plain text file in CSV-like format with the contents of the supplementary
information table with index YY. One-dimensional tables are presented as a
single-column file, whereas two-dimensional tables are presented as a table in
which column index denotes the index along the x dimension.

